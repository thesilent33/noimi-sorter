dataSetVersion = "2020-09-14"; // Change this when creating a new data set version. YYYY-MM-DD format.
dataSet[dataSetVersion] = {};

dataSet[dataSetVersion].options = [
  {
    name: "Filter by Member Generation",
    key: "generation",
    tooltip: "Check this to restrict per generation.",
    checked: false,
    sub: [
		{ name: "1st Generation", tooltip: "1st Generation of ≠ME",key: "1kisei" }
    ]
  },
  /*{
    name: "Filter by Sub Unit",
    key: "sub_unit",
    tooltip: "Check this to restrict members that appear in certain sub units.",
    checked: false,
    sub: [ 
		{ name: "5 Cantik", tooltip: "Sub unit consisting of Ushio Sarina, Takamoto Ayaka, Sasaki Kumi, Saito Kyoko and Kato Shiho", key: "5cantik" },
		{ name: "Hanachanzu", tooltip: "Sub unit consisting of Tomita Suzuka and Matsuda Konoka", key: "hanachanzu" },
		{ name: "Yancharu Family", tooltip: "Sub unit consisting of Higashimura Mei, Kanemura Miku, Kawata Hina and Nibu Akari for coupling song Cage from single Doremisolasido", key: "yancharu_family" },
		{ name: "Model 5", tooltip: "Sub unit consisting of 5 model of Hinatazaka46; Sasaki Mirei, Sasaki Kumi, Takamoto Ayaka, Kosaka Nao and Kato Shiho for coupling song Footstep from single Kyun", key: "model5" },
		{ name: "WakuWaku Peanuts", tooltip: "Unofficial sub unit consisting of Watanabe Miho and Tomita Suzuka", key: "waku2peanuts" },
		{ name: "GoriGori Donuts", tooltip: "Unofficial sub unit consisting of Watanabe Miho, Kanemura Miku and Nibu Akari", key: "gori2donuts" },
		{ name: "Saitama 3-nin Gumi", tooltip: "Unofficial sub unit consisting of 3 members from Saitama Prefecture; Watanabe Miho, Nibu Akari and Kanemura Miku", key: "saitama3ningumi" },
		{ name: "Hi Hi Sister", tooltip: "Unofficial sub unit consisting of Kawata Hina and Nibu Akari", key: "hihi_sister" }
    ]
  },*/
  {
    name: "Filter Activity Status",
    key: "activity_status",
    tooltip: "Check this to restrict members by activity status.",
    checked: false,
    sub: [
		{ name: "Active Member", tooltip: "Member who currently ungraduated", key: "active" },
		{ name: "Graduated", tooltip: "Member who already graduated", key: "graduated" }
    ]
  }
];

dataSet[dataSetVersion].characterData = [
  {
    name: "Ogi Hana",
    img: "ogi_hana.jpg",
    opts: {
      generation: [ "1kisei" ],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Ochiai Kirari",
    img: "ochiai_kirari.jpg",
    opts: {
      generation: [ "1kisei" ],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Kanisawa Moeko",
    img: "kanisawa_moeko.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Kawaguchi Natsune",
    img: "kawaguchi_natsune.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: ["", "model5"], activity_status: ["active"]
    }
  },
  {
    name: "Kawanago Natsumi",
    img: "kawanago_natsumi.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: ["", "model5"], activity_status: ["active"]
    }
  },
  {
    name: "Sakurai Momo",
    img: "sakurai_momo.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Suganami Mirei",
    img: "suganami_mirei.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: ["", ""], activity_status: ["active"]
    }
  },
  {
    name: "Suzuki Hitomi",
    img: "suzuki_hitomi.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Tanizaki Saya",
    img: "tanizaki_saya.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Tomita Nanaka",
    img: "tomita_suzuka.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Nagata Shiori",
    img: "nagata_shiori.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Honda Miyuki",
    img: "honda_miyuki.jpg",
    opts: {
      generation: ["1kisei"],
      sub_unit: [""], activity_status: ["active"]
    }
  }

];
